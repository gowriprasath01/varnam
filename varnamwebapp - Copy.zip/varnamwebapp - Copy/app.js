var exp = require("express");
var app = exp();
var mongoose=require("mongoose");
var bodyParser=require("body-parser");
var methodOverride=require("method-override");
var fs = require('fs'); 
var path = require('path'); 
require('dotenv/config'); 
var multer = require('multer'); 
var storage = multer.diskStorage({ 
    destination: (req, file, cb) => { 
        cb(null, 'uploads') 
    }, 
    filename: (req, file, cb) => { 
        cb(null, file.fieldname + '-' + Date.now()) 
    } 
}); 
  
var upload = multer({ storage: storage }); 





mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.set('useUnifiedTopology', true);
mongoose.connect("mongodb://localhost/varnam",{ useNewUrlParser: true, useUnifiedTopology: true }, err => { 
    console.log('connected') 
});

var profileSchema = new mongoose.Schema({
    Name : String,
    image: 
    { 
        data: Buffer, 
        contentType: String 
    } ,
    posting : String
});

var Profile = mongoose.model("profile", profileSchema)

var imageSchema = new mongoose.Schema({ 
    year : Number, 
    img: 
    { 
        data: Buffer, 
        contentType: String 
    } 
});

var Gallery= mongoose.model("'Image'", imageSchema)


app.use(bodyParser.urlencoded({ extended: false })) 
app.use(bodyParser.json()) 
app.set("view engine","ejs");

app.use(bodyParser.urlencoded({extended:true}));
app.use(methodOverride("_method"));

app.get("/",function(req,res){
 
    res.render("new");
})

app.post("/",function(req,res){
    console.log(req.body.File);
    res.send("you have posted successfully")
})




app.get("/next",function(req,res){

        res.render("next");
    
})

app.get("/team",function(req,res){
    console.log("you are here")
    Profile.find({},function(err,campgrounds){
        if(err){
            console.log(err);
        }else{
            res.render("team/profile",{profile:campgrounds});
        }
     })
})

app.get("/gallery",function(req,res){
    Gallery.find({},function(err,items){
        if(err){
            console.log(err);
        }else{
            res.render("yugam/gallery",{items:items})
        }

    })
   
})

app.get("/event_workshop",function(req,res){
    res.render("event/events")
})

app.get("/about",function(req,res){
    res.render("about")
})

app.get("/contactinfo",function(req,res){
    res.render("contact")
})

app.get("/adminvarnam123",function(req,res){
    res.render("admin")
})

app.get("/adminvarnam123/admingallery",function(req,res){
    res.render("admingallery")
})

app.get("/adminvarnam123/adminprofile",function(req,res){
    res.render("adminprofile")
})



app.get("/profile",function(req,res){
    console.log("you are here")
    Profile.find({},function(err,campgrounds){
        if(err){
            console.log(err);
        }else{
            console.log(campgrounds)
            res.render("adminprofileview",{items:campgrounds});
        }
     })
})

//creating the team member

// app.post("/profile",function(req,res){
//    console.log("you reached the post page")
//    var name = req.body.Name;
//    var image = req.body.Image;
//    var posting = req.body.Posting;
   
//    var newMember = {
//        Name : name,
//        image : image,
//        posting : posting

//    }

//    Profile.create(newMember,function(err,member){
//     if(err){
//       console.log(err);
//   }else{
//       console.log(member);
//       res.redirect("/profile");
//   }
// })


app.post('/profile', upload.single('image'), (req, res, next) => { 
    console.log("im here")
    var obj = { 
        Name: req.body.Name, 
        image: { 
            data: fs.readFileSync(path.join(__dirname + '/uploads/' + req.file.filename)), 
            contentType: 'image/png'
        } ,
        posting : req.body.Posting
    } 
    Profile.create(obj, (err, item) => { 
        if (err) { 
            console.log(err); 
        } 
        else { 
            // item.save(); 
            res.redirect('/profile'); 
        } 
    }); 
});

  //deteting the team member 

app.delete("/profile/:id",function(req,res){
    console.log(req.params.id)
    Profile.findByIdAndDelete(req.params.id,function(err){
        if(err){
            console.log(err)

        }else{
            console.log("deleted the person successfully")
            res.redirect("/profile");
        }
    })
})




// app.get("/admin/gallery",function(req,res){
//     res.render("you have reached finally")
// })


// app.post("/admin/gallery",function(req,res){
//     console.log(req.body.year);
//     console.log(req.body.Image)
//     var newGallery ={
//         year: req.body.year,
//         image : req.body.Image
//     }

//     Gallery.create(newGallery,function(err,photo){
//         if(err){
//           console.log(err);
//       }else{
//           console.log(photo);
//           res.redirect("/admin/gallery");
//       }
//     })
// })

//retrieving the image

app.get('/admin/gallery', (req, res) => { 
    console.log("you have been uploaded the image")
    Gallery.find({}, (err, items) => { 
        if (err) { 
            console.log(err); 
        } 
        else { 
            console.log(items)
            res.render('admingalleryview', { items: items }); 
        } 
    }); 
}); 




// Uploading the image 

app.post('/admin/gallery', upload.single('image'), (req, res, next) => { 
    console.log("im here")
    var obj = { 
        year: req.body.year, 
        img: { 
            data: fs.readFileSync(path.join(__dirname + '/uploads/' + req.file.filename)), 
            contentType: 'image/png'
        } 
    } 
    Gallery.create(obj, (err, item) => { 
        if (err) { 
            console.log(err); 
        } 
        else { 
            // item.save(); 
            res.redirect('/admin/gallery'); 
        } 
    }); 
});


//deleting the gallery

app.delete("admin/gallery/:id",function(req,res){
    console.log(req.params.id)
    Gallery.findByIdAndDelete(req.params.id,function(err){
        if(err){
            console.log(err)

        }else{
            console.log("deleted the person successfully")
            res.redirect("/admin/gallery");
        }
    })
})


app.listen(3000,function(){
    console.log("server started")
})